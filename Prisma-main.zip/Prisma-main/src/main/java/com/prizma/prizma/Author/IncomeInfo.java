package com.prizma.prizma.Author;

public class IncomeInfo {
    private double totalIncome;

    public IncomeInfo( double totalIncome) {
        this.totalIncome = totalIncome;
    }

    public double getTotalIncome() {
        return totalIncome;
    }

    public void setTotalIncome(double totalIncome) {
        this.totalIncome = totalIncome;
    }
}
